schedule function all_tasks:tasks/structure_loot/trial_chambers/corridor_barrel/trigger 1t
advancement revoke @s only all_tasks:tasks/structures/trial_chambers/loot_corridor_barrel/delay_trigger