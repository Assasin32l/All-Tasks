schedule function all_tasks:tasks/structure_loot/trial_chambers/supply_chest/trigger 1t
advancement revoke @s only all_tasks:tasks/structures/trial_chambers/loot_supply_chest/delay_trigger