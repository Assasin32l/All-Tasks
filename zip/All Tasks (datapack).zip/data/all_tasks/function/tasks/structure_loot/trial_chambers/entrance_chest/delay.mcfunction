schedule function all_tasks:tasks/structure_loot/trial_chambers/entrance_chest/trigger 1t
advancement revoke @s only all_tasks:tasks/structures/trial_chambers/loot_entrance_chest/delay_trigger